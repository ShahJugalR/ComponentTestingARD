/*
 *
 *
 *    @henil Plug the left and right leg of sensor in 5V and GND pin(there are 2 GND Pins test for each seperately)
 * 
 *    Plug the middle leg in pin 13
 *  
 *    Plug any color LED in pin 12
 */


void setup(){
    pinMode(13, INPUT);
    pinMode(12, OUTPUT);
}

void loop(){

    if(digitalRead(13) == HIGH){
        digitalWrite(12, LOW);
        return;
    }

    digitalWrite(12, HIGH);
}