
/*
 *
 *       @ Henil 13 ma no ni pin ma nakh ek ek karine LEDs With "Resistors"
 *  
 * 
 * 
 */

void setup(){
    pinMode(13, OUTPUT);
}

void loop(){
    digitalWrite(13, HIGH);
    delay(100);
    digitalWrite(13, LOW);
    delay(100);
}