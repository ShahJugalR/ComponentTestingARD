
/*
 *
 *       @ Henil 13 ma no ni pin ma nakh Buzzer Without "Resistors"
 *  
 * 
 * 
 */

void setup(){
    pinMode(13, OUTPUT);
}

void loop(){
    digitalWrite(13, HIGH);
    delay(100);
    digitalWrite(13, LOW);
    delay(100);
}